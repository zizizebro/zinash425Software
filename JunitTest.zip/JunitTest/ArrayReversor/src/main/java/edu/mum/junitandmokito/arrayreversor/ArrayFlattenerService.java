package edu.mum.junitandmokito.arrayreversor;

public interface ArrayFlattenerService {

    int[] flattenArray(int[][] a_in);
}
