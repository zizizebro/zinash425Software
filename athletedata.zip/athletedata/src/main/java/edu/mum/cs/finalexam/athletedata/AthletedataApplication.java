package edu.mum.cs.finalexam.athletedata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AthletedataApplication {

    public static void main(String[] args) {
        SpringApplication.run(AthletedataApplication.class, args);
    }

}
