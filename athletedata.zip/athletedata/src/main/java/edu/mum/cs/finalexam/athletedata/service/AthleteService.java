package edu.mum.cs.finalexam.athletedata.service;


import edu.mum.cs.finalexam.athletedata.model.Athlete;

public interface AthleteService {

    Iterable<Athlete> getAllAthlete();
    Athlete registerNewAthlete(Athlete athlete);

}
