package edu.mum.cs.finalexam.athletedata.service;

import edu.mum.cs.finalexam.athletedata.model.EliteAthlete;

public interface EliteAthletService {

    Iterable<EliteAthlete> getAllEliteAthlete();
    EliteAthlete registerNewEliteAthlete(EliteAthlete eliteAthlete);
}
