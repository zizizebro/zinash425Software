package edu.mum.cs.finalexam.athletedata.repositary;

import edu.mum.cs.finalexam.athletedata.model.EliteAthlete;
import org.springframework.data.repository.CrudRepository;

public interface EliteAthleteRepository extends CrudRepository<EliteAthlete, Long> {
}
