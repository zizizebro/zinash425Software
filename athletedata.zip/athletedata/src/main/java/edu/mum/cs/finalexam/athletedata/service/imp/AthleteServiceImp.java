package edu.mum.cs.finalexam.athletedata.service.imp;

import edu.mum.cs.finalexam.athletedata.model.Athlete;
import edu.mum.cs.finalexam.athletedata.repositary.AtheletRepository;
import edu.mum.cs.finalexam.athletedata.service.AthleteService;
import org.springframework.beans.factory.annotation.Autowired;

public class AthleteServiceImp implements AthleteService {
    @Autowired
    private AtheletRepository atheletRepository;
    @Override
    public Iterable<Athlete> getAllAthlete() {
        return atheletRepository.findAll();
    }

    @Override
    public Athlete registerNewAthlete(Athlete athlete) {
        return atheletRepository.save(athlete);
    }


}
