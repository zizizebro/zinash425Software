package edu.mum.cs.finalexam.athletedata.controller;

import edu.mum.cs.finalexam.athletedata.model.EliteAthlete;
import edu.mum.cs.finalexam.athletedata.service.EliteAthletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

public class EliiteAthleteControler {

    @Autowired
    private EliteAthletService eliteAthletService;

    @GetMapping(value = "/browse")
    public ModelAndView displayListOfEliteAthlet() {
        ModelAndView modelAndView = new ModelAndView();
        Iterable<EliteAthlete> eliteAthletes = eliteAthletService.getAllEliteAthlete();
        modelAndView.addObject("elite", eliteAthletes);
        modelAndView.setViewName("secured/supplier/browse");
        return modelAndView;
    }

    @GetMapping(value = "/new")
    public String newSupplierForm(Model model) {
        model.addAttribute("supplier", new EliteAthlete());
        return "secured/supplier/new";
    }

    @PostMapping(value = "/new")
    public String addNewSupplier(@Valid @ModelAttribute("supplier") EliteAthlete eliteAthlete,
                                 BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("errors", bindingResult.getAllErrors());
            return "secured/supplier/new";
        }
        eliteAthlete = (EliteAthlete) eliteAthletService.getAllEliteAthlete();
        return "redirect:/srm/secured/supplier/browse";
    }
}
