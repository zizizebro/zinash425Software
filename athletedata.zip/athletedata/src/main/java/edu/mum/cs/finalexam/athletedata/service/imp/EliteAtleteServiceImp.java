package edu.mum.cs.finalexam.athletedata.service.imp;

import edu.mum.cs.finalexam.athletedata.model.EliteAthlete;
import edu.mum.cs.finalexam.athletedata.repositary.EliteAthleteRepository;
import edu.mum.cs.finalexam.athletedata.service.EliteAthletService;
import org.springframework.beans.factory.annotation.Autowired;

public class EliteAtleteServiceImp implements EliteAthletService {

    @Autowired
    private EliteAthleteRepository eliteAthleteRepository;
    @Override
    public Iterable<EliteAthlete> getAllEliteAthlete() {
        return eliteAthleteRepository.findAll();
    }

    @Override
    public EliteAthlete registerNewEliteAthlete(EliteAthlete eliteAthlete) {
        return eliteAthleteRepository.save(eliteAthlete);
    }
}
