package edu.mum.cs.finalexam.athletedata.model;

import org.hibernate.validator.constraints.UniqueElements;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
public class Athlete {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long athleteId;
    @UniqueElements
    @NotNull(message = "* SSN  is required")
    @Digits(integer = 9, fraction = 0, message = "* SSN must be a positive, integral value")
    private int ssn;
    @NotNull(message = "* firstName  is required")
    private String firstName;
    @NotNull(message = "* firstName  is required")
    private String middleName;
    @NotNull(message = "* firstName  is required")
    private String lastName;
    private int phoneNumber;
    @NotNull(message = "* firstName  is required")
    @DateTimeFormat(pattern = "mm-dd-yyyy")
    private LocalDate dateOfBirth;
    @NotNull(message = "* firstName  is required")
    @DateTimeFormat(pattern = "mm-dd-yyyy")
    private LocalDate dateOfRegistration;
    @NotNull(message = "* firstName  is required")
    private int totalNumberOfMedalsWon;
    @NotNull(message = "* firstName  is required")
    private double monthlySalary;
    private String emailAddress;

    @OneToOne(cascade = CascadeType.ALL)
    EliteAthlete eliteAthlete;


    public Athlete(){

    }

    public Athlete(@UniqueElements int ssn, String firstName, String middleName, String lastName, int phoneNumber, LocalDate dateOfBirth,
                   LocalDate dateOfRegistration,
                   int totalNumberOfMedalsWon, double monthlySalary, String emailAddress, EliteAthlete eliteAthlete
    ) {
        this.ssn = ssn;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.dateOfBirth = dateOfBirth;
        this.dateOfRegistration = dateOfRegistration;
        this.totalNumberOfMedalsWon = totalNumberOfMedalsWon;
        this.monthlySalary = monthlySalary;
        this.emailAddress = emailAddress;
        this.eliteAthlete =eliteAthlete;
    }

    public Long getAthleteId() {
        return athleteId;
    }

    public void setAthleteId(Long athleteId) {
        this.athleteId = athleteId;
    }

    public int getSsn() {
        return ssn;
    }

    public void setSsn(int ssn) {
        this.ssn = ssn;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public LocalDate getDateOfRegistration() {
        return dateOfRegistration;
    }

    public void setDateOfRegistration(LocalDate dateOfRegistration) {
        this.dateOfRegistration = dateOfRegistration;
    }

    public int getTotalNumberOfMedalsWon() {
        return totalNumberOfMedalsWon;
    }

    public void setTotalNumberOfMedalsWon(int totalNumberOfMedalsWon) {
        this.totalNumberOfMedalsWon = totalNumberOfMedalsWon;
    }

    public double getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(double monthlySalary) {
        this.monthlySalary = monthlySalary;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
}
