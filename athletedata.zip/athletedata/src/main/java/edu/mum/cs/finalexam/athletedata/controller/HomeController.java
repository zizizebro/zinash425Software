package edu.mum.cs.finalexam.athletedata.controller;

import org.springframework.web.bind.annotation.GetMapping;

public class HomeController {

    @GetMapping(value = {"/srm", "/srm/home", "/"})
    public String displayHomePage() {
        return "public/home/index";
    }


}
