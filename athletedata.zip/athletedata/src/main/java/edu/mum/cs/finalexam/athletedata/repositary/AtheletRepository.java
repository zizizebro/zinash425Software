package edu.mum.cs.finalexam.athletedata.repositary;


import edu.mum.cs.finalexam.athletedata.model.Athlete;
import org.springframework.data.repository.CrudRepository;

public interface AtheletRepository extends CrudRepository<Athlete, Long> {

}
